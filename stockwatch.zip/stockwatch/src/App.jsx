import { useState, useEffect, useCallback } from "react";

const STORAGE_KEY = "stock_watchlist_v1";

const MARKET_EXAMPLES = {
  TH: ["PTT", "KBANK", "AOT", "CPALL", "SCB", "GULF", "ADVANC", "TRUE", "IVL", "SCC"],
  US: ["AAPL", "NVDA", "TSLA", "AMZN", "MSFT", "META", "GOOGL", "AMD", "PLTR", "SMCI"],
};

function useWatchlist() {
  const [list, setList] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  });

  const save = useCallback((newList) => {
    setList(newList);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(newList)); } catch {}
  }, []);

  const add = (item) => save([...list, { ...item, id: Date.now(), addedAt: new Date().toLocaleDateString("th-TH") }]);
  const remove = (id) => save(list.filter(i => i.id !== id));
  const update = (id, patch) => save(list.map(i => i.id === id ? { ...i, ...patch } : i));

  return { list, add, remove, update };
}

async function fetchQuote(symbol, market) {
  const ticker = market === "TH" ? `${symbol}.BK` : symbol;
  try {
    const res = await fetch(`/.netlify/functions/quote?symbol=${ticker}`);
    if (!res.ok) throw new Error("fetch failed");
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    return { ...data, symbol, market };
  } catch {
    return null;
  }
}

async function analyzeWithClaude(stockInfo, analysisType) {
  const prompts = {
    technical: `Analyze this stock with technical analysis perspective. Be concise (3-4 sentences). Stock: ${stockInfo.symbol} (${stockInfo.market} market), Current Price: ${stockInfo.price} ${stockInfo.currency}, Previous Close: ${stockInfo.prev}. Discuss momentum, trend, and key levels. End with a clear BUY / HOLD / SELL recommendation with brief reasoning.`,
    fundamental: `Give a brief fundamental analysis of ${stockInfo.symbol} listed on ${stockInfo.market === "TH" ? "Thailand Stock Exchange (SET)" : "US market"}. Current price: ${stockInfo.price} ${stockInfo.currency}. Discuss valuation, growth prospects, and competitive position in 3-4 sentences. End with BUY / HOLD / SELL recommendation.`,
    news: `Give a brief summary of recent news and sentiment for ${stockInfo.symbol} (${stockInfo.market === "TH" ? "Thai stock" : "US stock"}). What are the key catalysts or risks right now? Keep it to 3-4 sentences. End with how the news sentiment affects a BUY / HOLD / SELL decision.`,
  };

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: "You are a professional stock analyst with expertise in both Thai (SET) and US markets. Be direct, analytical, and always end with a clear BUY / HOLD / SELL recommendation highlighted in your response.",
      messages: [{ role: "user", content: prompts[analysisType] }],
    }),
  });

  const data = await response.json();
  return data.content?.[0]?.text || "Analysis unavailable.";
}

function extractSignal(text) {
  const upper = text.toUpperCase();
  if (upper.includes("STRONG BUY") || upper.includes("STRONG BUY")) return { label: "STRONG BUY", color: "#00ff88" };
  if (/\bBUY\b/.test(upper)) return { label: "BUY", color: "#00d4aa" };
  if (/\bSELL\b/.test(upper)) return { label: "SELL", color: "#ff4d6d" };
  return { label: "HOLD", color: "#f0a500" };
}

function PriceChange({ price, prev, currency }) {
  if (!price || !prev) return null;
  const diff = price - prev;
  const pct = ((diff / prev) * 100).toFixed(2);
  const up = diff >= 0;
  return (
    <span style={{ color: up ? "#00d4aa" : "#ff4d6d", fontFamily: "monospace", fontSize: "0.85rem" }}>
      {up ? "▲" : "▼"} {Math.abs(diff).toFixed(2)} ({up ? "+" : ""}{pct}%)
    </span>
  );
}

function AnalysisPanel({ stock, onClose }) {
  const [tab, setTab] = useState("technical");
  const [result, setResult] = useState({});
  const [loading, setLoading] = useState(false);
  const [quote, setQuote] = useState(null);

  useEffect(() => {
    fetchQuote(stock.symbol, stock.market).then(setQuote);
  }, [stock]);

  const analyze = async (type) => {
    setTab(type);
    if (result[type]) return;
    setLoading(true);
    const info = quote || { symbol: stock.symbol, market: stock.market, price: stock.price || "N/A", prev: stock.price, currency: stock.market === "TH" ? "THB" : "USD" };
    const text = await analyzeWithClaude(info, type);
    setResult(r => ({ ...r, [type]: text }));
    setLoading(false);
  };

  useEffect(() => { analyze("technical"); }, [quote]);

  const signal = result[tab] ? extractSignal(result[tab]) : null;

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", display: "flex",
      alignItems: "center", justifyContent: "center", zIndex: 1000, padding: "1rem"
    }}>
      <div style={{
        background: "#0d1117", border: "1px solid #21262d", borderRadius: "16px",
        width: "100%", maxWidth: "600px", maxHeight: "90vh", overflow: "auto",
        boxShadow: "0 0 60px rgba(0,212,170,0.15)"
      }}>
        {/* Header */}
        <div style={{ padding: "1.5rem 1.5rem 1rem", borderBottom: "1px solid #21262d" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
                <span style={{ fontSize: "1.5rem", fontWeight: 700, color: "#e6edf3", fontFamily: "monospace" }}>{stock.symbol}</span>
                <span style={{ background: stock.market === "TH" ? "#1a3a2a" : "#1a2a3a", color: stock.market === "TH" ? "#00d4aa" : "#58a6ff", padding: "2px 8px", borderRadius: "4px", fontSize: "0.7rem", fontWeight: 600 }}>{stock.market}</span>
                {signal && <span style={{ background: signal.color + "22", color: signal.color, padding: "3px 10px", borderRadius: "20px", fontSize: "0.75rem", fontWeight: 700, border: `1px solid ${signal.color}44` }}>{signal.label}</span>}
              </div>
              {quote && (
                <div style={{ marginTop: "0.35rem", fontSize: "1.1rem", color: "#e6edf3", fontFamily: "monospace" }}>
                  {quote.price?.toFixed(2)} <span style={{ color: "#8b949e", fontSize: "0.8rem" }}>{quote.currency}</span>
                  {" "}<PriceChange price={quote.price} prev={quote.prev} />
                </div>
              )}
            </div>
            <button onClick={onClose} style={{ background: "none", border: "none", color: "#8b949e", cursor: "pointer", fontSize: "1.3rem", lineHeight: 1 }}>✕</button>
          </div>

          {/* Tabs */}
          <div style={{ display: "flex", gap: "0.5rem", marginTop: "1rem" }}>
            {[["technical", "📈 Technical"], ["fundamental", "🏦 Fundamental"], ["news", "📰 News"]].map(([key, label]) => (
              <button key={key} onClick={() => analyze(key)} style={{
                padding: "6px 14px", borderRadius: "8px", fontSize: "0.78rem", fontWeight: 600, cursor: "pointer",
                border: tab === key ? "1px solid #00d4aa" : "1px solid #30363d",
                background: tab === key ? "#00d4aa18" : "transparent",
                color: tab === key ? "#00d4aa" : "#8b949e",
                transition: "all 0.2s"
              }}>{label}</button>
            ))}
          </div>
        </div>

        {/* Body */}
        <div style={{ padding: "1.5rem" }}>
          {loading ? (
            <div style={{ textAlign: "center", padding: "2rem", color: "#8b949e" }}>
              <div style={{ fontSize: "1.5rem", marginBottom: "0.5rem", animation: "spin 1s linear infinite" }}>⟳</div>
              <div style={{ fontSize: "0.85rem" }}>AI กำลังวิเคราะห์...</div>
            </div>
          ) : result[tab] ? (
            <div style={{ color: "#c9d1d9", lineHeight: 1.8, fontSize: "0.9rem", whiteSpace: "pre-wrap" }}>
              {result[tab]}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function AddStockModal({ onAdd, onClose }) {
  const [market, setMarket] = useState("US");
  const [symbol, setSymbol] = useState("");
  const [target, setTarget] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [quote, setQuote] = useState(null);
  const [error, setError] = useState("");

  const search = async () => {
    if (!symbol.trim()) return;
    setLoading(true); setError(""); setQuote(null);
    const q = await fetchQuote(symbol.trim().toUpperCase(), market);
    if (q) setQuote(q);
    else setError("ไม่พบหุ้นนี้ ลองเช็ค symbol อีกครั้ง");
    setLoading(false);
  };

  const handleAdd = () => {
    if (!quote) return;
    onAdd({ symbol: quote.symbol, market, name: quote.name, price: quote.price, target: target ? parseFloat(target) : null, note });
    onClose();
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: "1rem" }}>
      <div style={{ background: "#0d1117", border: "1px solid #21262d", borderRadius: "16px", width: "100%", maxWidth: "440px", padding: "1.5rem", boxShadow: "0 0 60px rgba(0,212,170,0.1)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "1.25rem" }}>
          <span style={{ color: "#e6edf3", fontWeight: 700, fontSize: "1rem" }}>เพิ่มหุ้นใน Watchlist</span>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "#8b949e", cursor: "pointer", fontSize: "1.2rem" }}>✕</button>
        </div>

        {/* Market toggle */}
        <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1rem" }}>
          {["TH", "US"].map(m => (
            <button key={m} onClick={() => { setMarket(m); setQuote(null); setError(""); }} style={{
              flex: 1, padding: "8px", borderRadius: "8px", fontWeight: 600, cursor: "pointer", fontSize: "0.85rem",
              border: market === m ? "1px solid #00d4aa" : "1px solid #30363d",
              background: market === m ? "#00d4aa18" : "transparent",
              color: market === m ? "#00d4aa" : "#8b949e",
            }}>
              {m === "TH" ? "🇹🇭 ไทย (SET)" : "🇺🇸 US"}
            </button>
          ))}
        </div>

        {/* Symbol search */}
        <div style={{ display: "flex", gap: "0.5rem", marginBottom: "0.5rem" }}>
          <input
            placeholder={market === "TH" ? "เช่น PTT, KBANK, AOT" : "เช่น AAPL, NVDA, TSLA"}
            value={symbol}
            onChange={e => setSymbol(e.target.value.toUpperCase())}
            onKeyDown={e => e.key === "Enter" && search()}
            style={{ flex: 1, background: "#161b22", border: "1px solid #30363d", color: "#e6edf3", borderRadius: "8px", padding: "8px 12px", fontSize: "0.9rem", fontFamily: "monospace" }}
          />
          <button onClick={search} style={{ background: "#00d4aa", color: "#000", border: "none", borderRadius: "8px", padding: "8px 16px", fontWeight: 700, cursor: "pointer", fontSize: "0.85rem" }}>
            {loading ? "..." : "ค้นหา"}
          </button>
        </div>

        {/* Example chips */}
        <div style={{ display: "flex", gap: "0.4rem", flexWrap: "wrap", marginBottom: "1rem" }}>
          {MARKET_EXAMPLES[market].slice(0, 6).map(s => (
            <button key={s} onClick={() => setSymbol(s)} style={{ background: "#21262d", border: "1px solid #30363d", color: "#8b949e", borderRadius: "4px", padding: "2px 8px", fontSize: "0.7rem", cursor: "pointer" }}>{s}</button>
          ))}
        </div>

        {error && <div style={{ color: "#ff4d6d", fontSize: "0.8rem", marginBottom: "0.75rem" }}>{error}</div>}

        {quote && (
          <div style={{ background: "#161b22", borderRadius: "10px", padding: "0.85rem", marginBottom: "1rem", border: "1px solid #00d4aa44" }}>
            <div style={{ color: "#e6edf3", fontWeight: 600, fontSize: "0.95rem" }}>{quote.name}</div>
            <div style={{ color: "#00d4aa", fontFamily: "monospace", fontSize: "1.1rem", marginTop: "0.25rem" }}>
              {quote.price?.toFixed(2)} <span style={{ color: "#8b949e", fontSize: "0.8rem" }}>{quote.currency}</span>
              {" "}<PriceChange price={quote.price} prev={quote.prev} />
            </div>
          </div>
        )}

        {quote && (
          <>
            <input
              placeholder="Target Price (ไม่บังคับ)"
              value={target}
              onChange={e => setTarget(e.target.value)}
              type="number"
              style={{ width: "100%", background: "#161b22", border: "1px solid #30363d", color: "#e6edf3", borderRadius: "8px", padding: "8px 12px", fontSize: "0.88rem", marginBottom: "0.5rem", boxSizing: "border-box" }}
            />
            <textarea
              placeholder="Note / เหตุผลที่ดูหุ้นนี้..."
              value={note}
              onChange={e => setNote(e.target.value)}
              rows={3}
              style={{ width: "100%", background: "#161b22", border: "1px solid #30363d", color: "#e6edf3", borderRadius: "8px", padding: "8px 12px", fontSize: "0.88rem", resize: "none", marginBottom: "1rem", boxSizing: "border-box" }}
            />
            <button onClick={handleAdd} style={{ width: "100%", background: "#00d4aa", color: "#000", border: "none", borderRadius: "8px", padding: "10px", fontWeight: 700, cursor: "pointer", fontSize: "0.9rem" }}>
              + เพิ่มใน Watchlist
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function StockCard({ item, onRemove, onAnalyze, onUpdate }) {
  const [quote, setQuote] = useState(null);
  const [editing, setEditing] = useState(false);
  const [note, setNote] = useState(item.note || "");
  const [target, setTarget] = useState(item.target || "");

  useEffect(() => {
    fetchQuote(item.symbol, item.market).then(setQuote);
  }, [item.symbol, item.market]);

  const price = quote?.price || item.price;
  const upside = item.target && price ? (((item.target - price) / price) * 100).toFixed(1) : null;
  const upsideUp = upside > 0;

  const saveEdit = () => {
    onUpdate(item.id, { note, target: target ? parseFloat(target) : null });
    setEditing(false);
  };

  return (
    <div style={{
      background: "#0d1117", border: "1px solid #21262d", borderRadius: "14px",
      padding: "1.1rem", transition: "border-color 0.2s",
      position: "relative", overflow: "hidden"
    }}
      onMouseEnter={e => e.currentTarget.style.borderColor = "#30363d"}
      onMouseLeave={e => e.currentTarget.style.borderColor = "#21262d"}
    >
      {/* Top row */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <span style={{ fontFamily: "monospace", fontWeight: 700, fontSize: "1rem", color: "#e6edf3" }}>{item.symbol}</span>
            <span style={{ background: item.market === "TH" ? "#1a3a2a" : "#1a2a3a", color: item.market === "TH" ? "#00d4aa" : "#58a6ff", padding: "1px 6px", borderRadius: "3px", fontSize: "0.65rem", fontWeight: 600 }}>{item.market}</span>
          </div>
          {quote?.name && <div style={{ color: "#8b949e", fontSize: "0.72rem", marginTop: "0.15rem", maxWidth: "160px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{quote.name}</div>}
        </div>
        <div style={{ display: "flex", gap: "0.4rem" }}>
          <button onClick={() => onAnalyze(item)} style={{ background: "#00d4aa18", border: "1px solid #00d4aa44", color: "#00d4aa", borderRadius: "6px", padding: "4px 8px", fontSize: "0.7rem", cursor: "pointer", fontWeight: 600 }}>AI ✦</button>
          <button onClick={() => setEditing(!editing)} style={{ background: "transparent", border: "1px solid #30363d", color: "#8b949e", borderRadius: "6px", padding: "4px 8px", fontSize: "0.7rem", cursor: "pointer" }}>✏️</button>
          <button onClick={() => onRemove(item.id)} style={{ background: "transparent", border: "none", color: "#8b949e", cursor: "pointer", fontSize: "0.9rem" }}>✕</button>
        </div>
      </div>

      {/* Price */}
      <div style={{ marginTop: "0.6rem" }}>
        <span style={{ fontFamily: "monospace", fontSize: "1.15rem", color: "#e6edf3", fontWeight: 600 }}>
          {price ? price.toFixed(2) : "—"}
        </span>
        {" "}
        {quote && <PriceChange price={quote.price} prev={quote.prev} />}
      </div>

      {/* Target + Upside */}
      {item.target && (
        <div style={{ marginTop: "0.4rem", display: "flex", gap: "0.75rem", alignItems: "center" }}>
          <span style={{ color: "#8b949e", fontSize: "0.75rem" }}>Target: <span style={{ color: "#e6edf3", fontFamily: "monospace" }}>{item.target}</span></span>
          {upside && (
            <span style={{ color: upsideUp ? "#00d4aa" : "#ff4d6d", fontSize: "0.75rem", fontWeight: 700 }}>
              {upsideUp ? "▲" : "▼"} {Math.abs(upside)}% {upsideUp ? "upside" : "downside"}
            </span>
          )}
        </div>
      )}

      {/* Note */}
      {item.note && !editing && (
        <div style={{ marginTop: "0.5rem", color: "#8b949e", fontSize: "0.75rem", fontStyle: "italic", borderLeft: "2px solid #21262d", paddingLeft: "0.5rem" }}>
          {item.note}
        </div>
      )}

      {/* Date */}
      <div style={{ marginTop: "0.5rem", color: "#484f58", fontSize: "0.68rem" }}>เพิ่มเมื่อ {item.addedAt}</div>

      {/* Edit panel */}
      {editing && (
        <div style={{ marginTop: "0.75rem", borderTop: "1px solid #21262d", paddingTop: "0.75rem" }}>
          <input value={target} onChange={e => setTarget(e.target.value)} placeholder="Target price" type="number"
            style={{ width: "100%", background: "#161b22", border: "1px solid #30363d", color: "#e6edf3", borderRadius: "6px", padding: "6px 10px", fontSize: "0.82rem", marginBottom: "0.4rem", boxSizing: "border-box" }} />
          <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Note..." rows={2}
            style={{ width: "100%", background: "#161b22", border: "1px solid #30363d", color: "#e6edf3", borderRadius: "6px", padding: "6px 10px", fontSize: "0.82rem", resize: "none", marginBottom: "0.4rem", boxSizing: "border-box" }} />
          <button onClick={saveEdit} style={{ background: "#00d4aa", color: "#000", border: "none", borderRadius: "6px", padding: "5px 14px", fontWeight: 700, cursor: "pointer", fontSize: "0.8rem" }}>บันทึก</button>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const { list, add, remove, update } = useWatchlist();
  const [showAdd, setShowAdd] = useState(false);
  const [analyzing, setAnalyzing] = useState(null);
  const [filter, setFilter] = useState("ALL");

  const filtered = filter === "ALL" ? list : list.filter(i => i.market === filter);

  return (
    <div style={{ minHeight: "100vh", background: "#010409", fontFamily: "'DM Sans', system-ui, sans-serif", color: "#e6edf3" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 6px; } ::-webkit-scrollbar-track { background: #0d1117; } ::-webkit-scrollbar-thumb { background: #30363d; border-radius: 3px; }
        input::placeholder, textarea::placeholder { color: #484f58; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        .card-grid > * { animation: fadeIn 0.3s ease forwards; }
      `}</style>

      {/* Header */}
      <div style={{ borderBottom: "1px solid #21262d", padding: "1rem 1.5rem", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, background: "#010409", zIndex: 100 }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
          <span style={{ fontSize: "1.2rem" }}>◈</span>
          <span style={{ fontWeight: 700, fontSize: "1rem", letterSpacing: "-0.02em", color: "#e6edf3" }}>StockWatch</span>
          <span style={{ color: "#00d4aa", fontSize: "0.7rem", fontWeight: 600, background: "#00d4aa18", padding: "2px 7px", borderRadius: "20px", border: "1px solid #00d4aa33" }}>AI</span>
        </div>
        <button onClick={() => setShowAdd(true)} style={{
          background: "#00d4aa", color: "#000", border: "none", borderRadius: "8px",
          padding: "7px 14px", fontWeight: 700, cursor: "pointer", fontSize: "0.82rem", display: "flex", alignItems: "center", gap: "0.3rem"
        }}>+ เพิ่มหุ้น</button>
      </div>

      <div style={{ maxWidth: "900px", margin: "0 auto", padding: "1.25rem 1rem" }}>
        {/* Filter tabs */}
        <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1.25rem" }}>
          {["ALL", "TH", "US"].map(m => (
            <button key={m} onClick={() => setFilter(m)} style={{
              padding: "6px 16px", borderRadius: "8px", fontSize: "0.8rem", fontWeight: 600, cursor: "pointer",
              border: filter === m ? "1px solid #00d4aa" : "1px solid #21262d",
              background: filter === m ? "#00d4aa18" : "transparent",
              color: filter === m ? "#00d4aa" : "#8b949e",
            }}>
              {m === "ALL" ? "ทั้งหมด" : m === "TH" ? "🇹🇭 ไทย" : "🇺🇸 US"}
              <span style={{ marginLeft: "0.4rem", fontSize: "0.7rem", color: "#484f58" }}>
                {m === "ALL" ? list.length : list.filter(i => i.market === m).length}
              </span>
            </button>
          ))}
        </div>

        {/* Empty state */}
        {filtered.length === 0 && (
          <div style={{ textAlign: "center", padding: "3rem 1rem", color: "#484f58" }}>
            <div style={{ fontSize: "2.5rem", marginBottom: "0.75rem" }}>◈</div>
            <div style={{ fontSize: "0.95rem", marginBottom: "0.35rem", color: "#8b949e" }}>Watchlist ว่างอยู่</div>
            <div style={{ fontSize: "0.8rem" }}>กด "+ เพิ่มหุ้น" เพื่อเริ่มติดตามหุ้นที่มี upside potential</div>
          </div>
        )}

        {/* Grid */}
        <div className="card-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: "0.85rem" }}>
          {filtered.map(item => (
            <StockCard key={item.id} item={item} onRemove={remove} onAnalyze={setAnalyzing} onUpdate={update} />
          ))}
        </div>
      </div>

      {showAdd && <AddStockModal onAdd={add} onClose={() => setShowAdd(false)} />}
      {analyzing && <AnalysisPanel stock={analyzing} onClose={() => setAnalyzing(null)} />}
    </div>
  );
}
